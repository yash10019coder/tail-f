#!/bin/bash

for i in {1..1000}; do date >> sample.log; sleep 1; done
